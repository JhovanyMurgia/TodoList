# Deploy

## Render

1. Criar um novo Web Service.
2. Conectar o repositorio GitHub.
3. Configurar o ambiente como Node.
4. Usar os comandos:

```txt
Build Command: npm install
Start Command: npm start
```

5. Publicar e testar a URL gerada pelo Render.

## GitHub Pages com MkDocs

Instalar o tema:

```bash
pip install mkdocs-material
```

Publicar:

```bash
mkdocs gh-deploy
```

Depois, acessar:

```txt
https://seu-usuario.github.io/todo-list
```
